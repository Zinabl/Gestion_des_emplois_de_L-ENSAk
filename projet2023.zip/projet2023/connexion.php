<?php
$link=mysqli_connect("localhost","root","","rat")or die("Echec de connexion à la base");
?>